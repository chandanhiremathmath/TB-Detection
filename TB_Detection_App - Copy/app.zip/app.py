# from flask import Flask, render_template, request
# import joblib
# import numpy as np
# from keras.models import load_model
# from keras.preprocessing import image
# import os
# # from gradcam_utils import compute_gradcam



# app = Flask(__name__)
# app.config['UPLOAD_FOLDER'] = 'static/uploads'



# # Load models
# symptom_model = joblib.load('symptom_model.pkl')
# xray_model = load_model('tb_model.h5')

# #sample
# # Load models
# # symptom_model = joblib.load('symptom_model.pkl')
# # xray_model = load_model('tb_model.h5')

# # 👇 Do a dummy call to "build" the model
# # _ = xray_model.predict(np.zeros((1, 224, 224, 3)))


# for layer in xray_model.layers:
#     print(layer.name, layer.output.shape)



# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/predict_xray', methods=['POST'])
# def predict_xray():
#     if 'xray' not in request.files:
#         return "No file selected"
#     img_file = request.files['xray']
#     filepath = os.path.join(app.config['UPLOAD_FOLDER'], img_file.filename)
#     img_file.save(filepath)

#     img = image.load_img(filepath, target_size=(224, 224))
#     img_tensor = image.img_to_array(img) / 255.0
#     img_tensor = np.expand_dims(img_tensor, axis=0)

#     prediction = xray_model.predict(img_tensor)[0][0]
#     result = 'Tuberculosis Detected' if prediction > 0.5 else 'Normal'
#     #some
#     # gradcam_path = compute_gradcam(xray_model, filepath, layer_name="conv2d_2")
#     # gradcam_url = f"/{gradcam_path}"  
#     # For HTML template
#     return render_template('result.html', result=result, image_path=filepath)


# @app.route('/predict_symptoms', methods=['POST'])
# def predict_symptoms():
#     try:
#         features = [
#             int(request.form['gender']),
#             int(request.form['cough']),
#             int(request.form['fever']),
#             int(request.form['chest_pain']),
#             int(request.form['fatigue']),
#             int(request.form['hemoptysis']),
#             int(request.form['night_sweats']),
#             int(request.form['weight_loss']),
#             int(request.form['shortness_of_breath']),
#             int(request.form['loss_of_appetite']),
#         ]
#         prediction = symptom_model.predict([features])[0]
#         result = 'Tuberculosis Detected' if prediction == 1 else 'Normal'
#         return render_template('result.html', result=result, image_path=None)
#     except Exception as e:
#         return f"Error: {e}"

# if __name__ == '__main__':
#     app.run(debug=True)
import openai
from flask import request, jsonify
from flask import Flask, render_template, request, redirect, url_for, session,flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required,UserMixin, logout_user, current_user
from models import db, User
from werkzeug.security import generate_password_hash, check_password_hash
import joblib
import numpy as np
from keras.models import load_model
from keras.preprocessing import image
import os
from datetime import datetime
from flask_pymongo import PyMongo
from flask_login import logout_user


app = Flask(__name__,template_folder='templates')
app.secret_key = 'your_secret_key'
app.config["MONGO_URI"] = "mongodb://localhost:27017/tb_detection_db"
mongo = PyMongo(app)

openai.api_key = os.getenv("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")


app.config['UPLOAD_FOLDER'] = 'static/uploads'



# Load models
symptom_model = joblib.load('symptom_model.pkl')
xray_model = load_model('tb_model.h5')

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         email = request.form['email']
#         password = request.form['password']
        
#         # Check credentials
#         if email in users and users[email] == password:
#             session['user'] = email  # Save login info
#             return redirect('/symptoms')
#         else:
#             flash('❌ Invalid email or password.')
    
#     return render_template('login.html', active='login')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = mongo.db.users.find_one({'email': email})

        if user and check_password_hash(user['password'], password):
            session['user'] = email
            return redirect('/symptoms')
        else:
            flash('❌ Invalid email or password.')

    return render_template('login.html', active='login')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = generate_password_hash(request.form['password'])

        if mongo.db.users.find_one({'email': email}):
            flash("Email already registered.")
        else:
            mongo.db.users.insert_one({'email': email, 'password': password})
            flash("Registration successful! Please login.")
            return redirect('/login')

    return render_template('register.html')


@app.route('/symptoms')
def symptoms():
    if 'user' not in session:
        return redirect('/login')  # Force login
    return render_template('symptoms.html')

# @app.route('/logout')
# def logout():
#     session.pop('user', None)
#     return redirect('/login')
@app.route('/quiz')
def quiz():
    # Ensure the user is logged in
    if 'user' not in session:
        return redirect('/login')  # Redirect to login if not authenticated

    # Render the quiz page
    return render_template('quiz.html')



@app.route('/')
def home():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('home.html')


@app.route('/predict_symptoms_step', methods=['POST'])
def predict_symptoms_step():
    try:
        features = [
            int(request.form['gender']),
            int(request.form['cough']),
            int(request.form['fever']),
            int(request.form['chest_pain']),
            int(request.form['fatigue']),
            int(request.form['hemoptysis']),
            int(request.form['night_sweats']),
            int(request.form['weight_loss']),
            int(request.form['shortness_of_breath']),
            int(request.form['loss_of_appetite']),
        ]
        prediction = symptom_model.predict([features])[0]
        result = 'Tuberculosis Detected' if prediction == 1 else 'Normal'
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # 🕒 ADD THIS
        mongo.db.predictions.insert_one({
         'user': session.get('user'),
         'type': 'symptoms',
         'features': features,
         'result': result,
         'timestamp': timestamp
          })



        if prediction == 1:
            session['symptom_result'] = 'TB suspected from symptoms'
            return render_template('xray_upload.html')
        else:
            result = 'No TB symptoms detected'
            return render_template('result.html', result=result, image_path=None)
    except Exception as e:
        return f"Error: {e}"

    



@app.route('/predict_xray_step', methods=['POST'])
def predict_xray_step():
    try:
        if 'xray' not in request.files:
            return "No X-ray file provided"
        img_file = request.files['xray']
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], img_file.filename)
        img_file.save(filepath)

        img = image.load_img(filepath, target_size=(224, 224))
        img_tensor = image.img_to_array(img) / 255.0
        img_tensor = np.expand_dims(img_tensor, axis=0)

        prediction = xray_model.predict(img_tensor)[0][0]
        xray_result = 'TB confirmed from X-ray' if prediction > 0.5 else 'X-ray appears normal'
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # 🕒 ADD THIS
        mongo.db.predictions.insert_one({
    'user': session.get('user'),
    'type': 'xray',
    'result': xray_result,
    'image_path': filepath,
    'timestamp': timestamp
})



        final_result = f"{session.get('symptom_result', '')} | {xray_result}"
        return render_template('result.html', result=final_result, image_path=filepath, timestamp=timestamp)

    except Exception as e:
        return f"Error: {e}"
    
    
@app.route('/reports')
def reports():
    if 'user' not in session:
        return redirect('/login')

    user_reports = list(mongo.db.predictions.find({'user': session['user']}))
    return render_template('reports.html', reports=user_reports)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_msg = data.get("message", "")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful medical assistant specializing in tuberculosis information."},
                {"role": "user", "content": user_msg}
            ]
        )
        reply = response['choices'][0]['message']['content']
        return jsonify({"reply": reply})

    except Exception as e:
        return jsonify({"reply": "Sorry, something went wrong."})

if __name__ == '__main__':
    app.run(debug=True)
